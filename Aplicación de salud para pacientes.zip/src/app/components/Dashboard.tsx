import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Activity, Pill, Droplet, Heart, AlertTriangle } from 'lucide-react';
import { Badge } from './ui/badge';
import { mockMedications, mockGlucoseReadings, mockBloodPressureReadings, mockAlerts } from '../data/mockData';

export function Dashboard() {
  const todayMeds = mockMedications.filter(med => {
    const medDate = new Date(med.timestamp);
    const now = new Date();
    return medDate.toDateString() === now.toDateString();
  });
  const takenMeds = todayMeds.filter(m => m.taken).length;
  const latestGlucose = mockGlucoseReadings[mockGlucoseReadings.length - 1];
  const latestBP = mockBloodPressureReadings[mockBloodPressureReadings.length - 1];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Panel de Control</h1>
        <p className="text-muted-foreground">
          Resumen de su salud y actividad reciente
        </p>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Medicamentos Hoy</CardTitle>
            <Pill className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{takenMeds}/{todayMeds.length}</div>
            <p className="text-xs text-muted-foreground">
              {takenMeds === todayMeds.length ? 'Todos tomados' : `${todayMeds.length - takenMeds} pendientes`}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Glucosa Actual</CardTitle>
            <Droplet className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{latestGlucose.value} mg/dL</div>
            <p className="text-xs text-muted-foreground">
              {latestGlucose.timestamp.toLocaleDateString('es-ES', { month: 'short', day: 'numeric' })}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Presión Arterial</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{latestBP.systolic}/{latestBP.diastolic}</div>
            <p className="text-xs text-muted-foreground">mmHg</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alertas Activas</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{mockAlerts.length}</div>
            <p className="text-xs text-muted-foreground">
              Requieren atención
            </p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Actividad Reciente</CardTitle>
            <CardDescription>Últimas 5 acciones registradas</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-primary" />
              <div className="flex-1">
                <p className="text-sm font-medium">Presión arterial registrada</p>
                <p className="text-xs text-muted-foreground">
                  {latestBP.timestamp.toLocaleDateString('es-ES', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
              <Badge variant="outline">{latestBP.systolic}/{latestBP.diastolic}</Badge>
            </div>
            <div className="flex items-center gap-3">
              <div className="h-2 w-2 rounded-full bg-primary" />
              <div className="flex-1">
                <p className="text-sm font-medium">Glucosa registrada</p>
                <p className="text-xs text-muted-foreground">
                  {latestGlucose.timestamp.toLocaleDateString('es-ES', {
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
              <Badge variant="outline">{latestGlucose.value} mg/dL</Badge>
            </div>
            {todayMeds.filter(m => m.taken).slice(0, 3).map(med => (
              <div key={med.id} className="flex items-center gap-3">
                <div className="h-2 w-2 rounded-full bg-primary" />
                <div className="flex-1">
                  <p className="text-sm font-medium">Medicamento tomado</p>
                  <p className="text-xs text-muted-foreground">
                    {med.timestamp.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
                <Badge variant="outline">{med.medicationName}</Badge>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              <CardTitle>Estado de Salud</CardTitle>
            </div>
            <CardDescription>Resumen de indicadores clave</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Adherencia a medicamentos</span>
                <span className="text-sm text-muted-foreground">
                  {Math.round((takenMeds / todayMeds.length) * 100)}%
                </span>
              </div>
              <div className="h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary transition-all"
                  style={{ width: `${(takenMeds / todayMeds.length) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Glucosa</span>
                <Badge variant={latestGlucose.value > 140 ? 'destructive' : 'default'}>
                  {latestGlucose.value > 140 ? 'Alta' : 'Normal'}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                Último registro: {latestGlucose.value} mg/dL
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Presión Arterial</span>
                <Badge variant={latestBP.systolic > 120 ? 'destructive' : 'default'}>
                  {latestBP.systolic > 120 ? 'Alta' : 'Normal'}
                </Badge>
              </div>
              <p className="text-xs text-muted-foreground">
                Último registro: {latestBP.systolic}/{latestBP.diastolic} mmHg
              </p>
            </div>

            <div className="pt-4 border-t">
              <p className="text-sm">
                <span className="font-medium">Próxima acción: </span>
                <span className="text-muted-foreground">
                  {todayMeds.find(m => !m.taken)
                    ? `Tomar ${todayMeds.find(m => !m.taken)?.medicationName} a las ${todayMeds.find(m => !m.taken)?.timestamp.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`
                    : 'Todos los medicamentos del día tomados'
                  }
                </span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
