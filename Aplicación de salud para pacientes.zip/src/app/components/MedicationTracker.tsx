import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { Badge } from './ui/badge';
import { Pill, Plus } from 'lucide-react';
import { MedicationDose } from '../types';
import { mockMedications } from '../data/mockData';

export function MedicationTracker() {
  const [medications, setMedications] = useState<MedicationDose[]>(mockMedications);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newMed, setNewMed] = useState({ name: '', dose: '', time: '' });

  const toggleMedication = (id: string) => {
    setMedications(medications.map(med =>
      med.id === id ? { ...med, taken: !med.taken } : med
    ));
  };

  const addMedication = () => {
    if (newMed.name && newMed.dose && newMed.time) {
      const medication: MedicationDose = {
        id: Date.now().toString(),
        medicationName: newMed.name,
        dose: newMed.dose,
        timestamp: new Date(`2026-05-28 ${newMed.time}`),
        taken: false,
      };
      setMedications([...medications, medication]);
      setNewMed({ name: '', dose: '', time: '' });
      setShowAddForm(false);
    }
  };

  const today = medications.filter(med => {
    const medDate = new Date(med.timestamp);
    const now = new Date();
    return medDate.toDateString() === now.toDateString();
  });

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Pill className="h-5 w-5" />
              <CardTitle>Registro de Medicamentos</CardTitle>
            </div>
            <Button onClick={() => setShowAddForm(!showAddForm)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Agregar
            </Button>
          </div>
          <CardDescription>Marque los medicamentos que ya ha tomado hoy</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {showAddForm && (
            <Card className="border-2 border-dashed">
              <CardContent className="pt-6 space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="med-name">Nombre del medicamento</Label>
                  <Input
                    id="med-name"
                    placeholder="Ej: Metformina"
                    value={newMed.name}
                    onChange={(e) => setNewMed({ ...newMed, name: e.target.value })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="med-dose">Dosis</Label>
                  <Input
                    id="med-dose"
                    placeholder="Ej: 500mg"
                    value={newMed.dose}
                    onChange={(e) => setNewMed({ ...newMed, dose: e.target.value })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="med-time">Hora</Label>
                  <Input
                    id="med-time"
                    type="time"
                    value={newMed.time}
                    onChange={(e) => setNewMed({ ...newMed, time: e.target.value })}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={addMedication} className="flex-1">Agregar</Button>
                  <Button onClick={() => setShowAddForm(false)} variant="outline" className="flex-1">
                    Cancelar
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-3">
            {today.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">
                No hay medicamentos programados para hoy
              </p>
            ) : (
              today.map((med) => (
                <div
                  key={med.id}
                  className="flex items-center gap-4 p-4 border rounded-lg hover:bg-accent/50 transition-colors"
                >
                  <Checkbox
                    checked={med.taken}
                    onCheckedChange={() => toggleMedication(med.id)}
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <p className={`font-medium ${med.taken ? 'line-through text-muted-foreground' : ''}`}>
                        {med.medicationName}
                      </p>
                      {med.taken && <Badge variant="secondary">Tomado</Badge>}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {med.dose} • {med.timestamp.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
