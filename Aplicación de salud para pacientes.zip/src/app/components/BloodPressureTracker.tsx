import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Heart, Plus, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { BloodPressureReading, HealthRange } from '../types';
import { mockBloodPressureReadings, defaultRanges } from '../data/mockData';

export function BloodPressureTracker() {
  const [readings, setReadings] = useState<BloodPressureReading[]>(mockBloodPressureReadings);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newReading, setNewReading] = useState({ systolic: '', diastolic: '', note: '' });

  const systolicRange = defaultRanges.find(r => r.type === 'systolic') as HealthRange;
  const diastolicRange = defaultRanges.find(r => r.type === 'diastolic') as HealthRange;

  const getStatus = (systolic: number, diastolic: number) => {
    const systolicHigh = systolic > systolicRange.normalMax;
    const diastolicHigh = diastolic > diastolicRange.normalMax;
    const systolicLow = systolic < systolicRange.low;
    const diastolicLow = diastolic < diastolicRange.low;

    if (systolicHigh || diastolicHigh) return { label: 'ALTA', variant: 'destructive' as const };
    if (systolicLow || diastolicLow) return { label: 'BAJA', variant: 'destructive' as const };
    return { label: 'NORMAL', variant: 'default' as const };
  };

  const addReading = () => {
    if (newReading.systolic && newReading.diastolic) {
      const reading: BloodPressureReading = {
        id: Date.now().toString(),
        systolic: parseFloat(newReading.systolic),
        diastolic: parseFloat(newReading.diastolic),
        timestamp: new Date(),
        note: newReading.note || undefined,
      };
      setReadings([...readings, reading]);
      setNewReading({ systolic: '', diastolic: '', note: '' });
      setShowAddForm(false);
    }
  };

  const chartData = readings
    .slice(-10)
    .map(r => ({
      date: r.timestamp.toLocaleDateString('es-ES', { month: 'short', day: 'numeric' }),
      systolic: r.systolic,
      diastolic: r.diastolic,
      time: r.timestamp.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
    }));

  const latestReading = readings[readings.length - 1];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="h-5 w-5" />
              <CardTitle>Presión Arterial</CardTitle>
            </div>
            <Button onClick={() => setShowAddForm(!showAddForm)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Registrar
            </Button>
          </div>
          <CardDescription>Monitoreo de presión arterial (mmHg)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {latestReading && (
            <div className="p-6 bg-accent/50 rounded-lg">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold">{latestReading.systolic}/{latestReading.diastolic}</span>
                <span className="text-muted-foreground">mmHg</span>
                <Badge {...getStatus(latestReading.systolic, latestReading.diastolic)} className="ml-2">
                  {getStatus(latestReading.systolic, latestReading.diastolic).label}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                Sistólica/Diastólica
              </p>
              <p className="text-sm text-muted-foreground">
                {latestReading.timestamp.toLocaleDateString('es-ES', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          )}

          {showAddForm && (
            <Card className="border-2 border-dashed">
              <CardContent className="pt-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="systolic">Sistólica (mmHg)</Label>
                    <Input
                      id="systolic"
                      type="number"
                      placeholder="120"
                      value={newReading.systolic}
                      onChange={(e) => setNewReading({ ...newReading, systolic: e.target.value })}
                    />
                  </div>
                  <div className="grid gap-2">
                    <Label htmlFor="diastolic">Diastólica (mmHg)</Label>
                    <Input
                      id="diastolic"
                      type="number"
                      placeholder="80"
                      value={newReading.diastolic}
                      onChange={(e) => setNewReading({ ...newReading, diastolic: e.target.value })}
                    />
                  </div>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="bp-note">Nota (opcional)</Label>
                  <Input
                    id="bp-note"
                    placeholder="Ej: Después de ejercicio"
                    value={newReading.note}
                    onChange={(e) => setNewReading({ ...newReading, note: e.target.value })}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={addReading} className="flex-1">Registrar</Button>
                  <Button onClick={() => setShowAddForm(false)} variant="outline" className="flex-1">
                    Cancelar
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div>
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="h-4 w-4" />
              <h3 className="font-medium">Tendencia (últimos 10 registros)</h3>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis domain={[50, 150]} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-background border rounded-lg p-3 shadow-lg">
                          <p className="font-medium">{payload[0].value}/{payload[1].value} mmHg</p>
                          <p className="text-sm text-muted-foreground">{payload[0].payload.time}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <ReferenceLine y={systolicRange.normalMax} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
                <ReferenceLine y={diastolicRange.normalMax} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
                <Line
                  type="monotone"
                  dataKey="systolic"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  name="Sistólica"
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  type="monotone"
                  dataKey="diastolic"
                  stroke="hsl(var(--chart-2))"
                  strokeWidth={2}
                  name="Diastólica"
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex items-center justify-center gap-6 mt-4 text-sm flex-wrap">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-primary rounded-full" />
                <span>Sistólica</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-chart-2 rounded-full" />
                <span>Diastólica</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-destructive rounded-full" />
                <span>Límites de riesgo</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Historial reciente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {readings.slice(-5).reverse().map((reading) => (
              <div key={reading.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{reading.systolic}/{reading.diastolic} mmHg</span>
                    <Badge {...getStatus(reading.systolic, reading.diastolic)} variant="outline">
                      {getStatus(reading.systolic, reading.diastolic).label}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {reading.timestamp.toLocaleDateString('es-ES', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                    {reading.note && ` • ${reading.note}`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
