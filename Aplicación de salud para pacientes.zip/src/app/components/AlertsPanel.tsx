import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { AlertTriangle, Activity } from 'lucide-react';
import { Alert } from '../types';
import { mockAlerts } from '../data/mockData';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

export function AlertsPanel() {
  const [alerts] = useState<Alert[]>(mockAlerts);

  const glucoseAlerts = alerts.filter(a => a.type === 'glucose');
  const bpAlerts = alerts.filter(a => a.type === 'blood-pressure');

  const AlertCard = ({ alert }: { alert: Alert }) => (
    <div className="p-4 border-l-4 border-l-destructive bg-destructive/5 rounded-lg">
      <div className="flex items-start gap-3">
        <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-1">
            <Badge variant="destructive">{alert.severity === 'high' ? 'ALTO' : 'BAJO'}</Badge>
            <span className="text-sm text-muted-foreground">
              {alert.type === 'glucose' ? 'Glucosa' : 'Presión Arterial'}
            </span>
          </div>
          {alert.patientName && (
            <p className="font-medium mb-1">Paciente: {alert.patientName}</p>
          )}
          <p className="text-2xl font-bold mb-1">
            {alert.value} {alert.type === 'glucose' ? 'mg/dL' : 'mmHg'}
          </p>
          <p className="text-sm text-muted-foreground">
            {alert.timestamp.toLocaleDateString('es-ES', {
              weekday: 'long',
              month: 'long',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            })}
          </p>
        </div>
      </div>
    </div>
  );

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          <CardTitle>Panel de Alertas del Consultorio</CardTitle>
        </div>
        <CardDescription>
          Registros fuera de rango que requieren atención médica
        </CardDescription>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">No hay alertas activas</p>
            <p className="text-sm text-muted-foreground mt-1">
              Todos los pacientes tienen valores dentro de rangos normales
            </p>
          </div>
        ) : (
          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="all">
                Todas ({alerts.length})
              </TabsTrigger>
              <TabsTrigger value="glucose">
                Glucosa ({glucoseAlerts.length})
              </TabsTrigger>
              <TabsTrigger value="bp">
                Presión ({bpAlerts.length})
              </TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="space-y-4 mt-4">
              {alerts.map(alert => (
                <AlertCard key={alert.id} alert={alert} />
              ))}
            </TabsContent>
            <TabsContent value="glucose" className="space-y-4 mt-4">
              {glucoseAlerts.length === 0 ? (
                <p className="text-center py-4 text-muted-foreground">
                  No hay alertas de glucosa
                </p>
              ) : (
                glucoseAlerts.map(alert => (
                  <AlertCard key={alert.id} alert={alert} />
                ))
              )}
            </TabsContent>
            <TabsContent value="bp" className="space-y-4 mt-4">
              {bpAlerts.length === 0 ? (
                <p className="text-center py-4 text-muted-foreground">
                  No hay alertas de presión arterial
                </p>
              ) : (
                bpAlerts.map(alert => (
                  <AlertCard key={alert.id} alert={alert} />
                ))
              )}
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
}
