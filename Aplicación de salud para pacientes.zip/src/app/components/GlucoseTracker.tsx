import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Droplet, Plus, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { GlucoseReading, HealthRange } from '../types';
import { mockGlucoseReadings, defaultRanges } from '../data/mockData';

export function GlucoseTracker() {
  const [readings, setReadings] = useState<GlucoseReading[]>(mockGlucoseReadings);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newReading, setNewReading] = useState({ value: '', note: '' });

  const glucoseRange = defaultRanges.find(r => r.type === 'glucose') as HealthRange;

  const getStatus = (value: number) => {
    if (value < glucoseRange.low) return { label: 'BAJO', variant: 'destructive' as const };
    if (value <= glucoseRange.normalMax) return { label: 'NORMAL', variant: 'default' as const };
    return { label: 'ALTO', variant: 'destructive' as const };
  };

  const addReading = () => {
    if (newReading.value) {
      const reading: GlucoseReading = {
        id: Date.now().toString(),
        value: parseFloat(newReading.value),
        timestamp: new Date(),
        note: newReading.note || undefined,
      };
      setReadings([...readings, reading]);
      setNewReading({ value: '', note: '' });
      setShowAddForm(false);
    }
  };

  const chartData = readings
    .slice(-10)
    .map(r => ({
      date: r.timestamp.toLocaleDateString('es-ES', { month: 'short', day: 'numeric' }),
      value: r.value,
      time: r.timestamp.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' }),
    }));

  const latestReading = readings[readings.length - 1];

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Droplet className="h-5 w-5" />
              <CardTitle>Glucosa</CardTitle>
            </div>
            <Button onClick={() => setShowAddForm(!showAddForm)} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Registrar
            </Button>
          </div>
          <CardDescription>Niveles de glucosa en sangre (mg/dL)</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {latestReading && (
            <div className="p-6 bg-accent/50 rounded-lg">
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold">{latestReading.value}</span>
                <span className="text-muted-foreground">mg/dL</span>
                <Badge {...getStatus(latestReading.value)} className="ml-2">
                  {getStatus(latestReading.value).label}
                </Badge>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                {latestReading.timestamp.toLocaleDateString('es-ES', {
                  weekday: 'long',
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          )}

          {showAddForm && (
            <Card className="border-2 border-dashed">
              <CardContent className="pt-6 space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="glucose-value">Nivel de glucosa (mg/dL)</Label>
                  <Input
                    id="glucose-value"
                    type="number"
                    placeholder="Ej: 95"
                    value={newReading.value}
                    onChange={(e) => setNewReading({ ...newReading, value: e.target.value })}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="glucose-note">Nota (opcional)</Label>
                  <Input
                    id="glucose-note"
                    placeholder="Ej: En ayunas"
                    value={newReading.note}
                    onChange={(e) => setNewReading({ ...newReading, note: e.target.value })}
                  />
                </div>
                <div className="flex gap-2">
                  <Button onClick={addReading} className="flex-1">Registrar</Button>
                  <Button onClick={() => setShowAddForm(false)} variant="outline" className="flex-1">
                    Cancelar
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div>
            <div className="flex items-center gap-2 mb-4">
              <TrendingUp className="h-4 w-4" />
              <h3 className="font-medium">Tendencia (últimos 10 registros)</h3>
            </div>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis domain={[60, 180]} />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      return (
                        <div className="bg-background border rounded-lg p-3 shadow-lg">
                          <p className="font-medium">{payload[0].value} mg/dL</p>
                          <p className="text-sm text-muted-foreground">{payload[0].payload.time}</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <ReferenceLine y={glucoseRange.normalMax} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
                <ReferenceLine y={glucoseRange.low} stroke="hsl(var(--destructive))" strokeDasharray="3 3" />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
            <div className="flex items-center justify-center gap-6 mt-4 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-destructive rounded-full" />
                <span>Riesgo: &lt;{glucoseRange.low} o &gt;{glucoseRange.normalMax} mg/dL</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-primary rounded-full" />
                <span>Normal: {glucoseRange.normalMin}-{glucoseRange.normalMax} mg/dL</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Historial reciente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {readings.slice(-5).reverse().map((reading) => (
              <div key={reading.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{reading.value} mg/dL</span>
                    <Badge {...getStatus(reading.value)} variant="outline">
                      {getStatus(reading.value).label}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {reading.timestamp.toLocaleDateString('es-ES', {
                      month: 'short',
                      day: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit'
                    })}
                    {reading.note && ` • ${reading.note}`}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
