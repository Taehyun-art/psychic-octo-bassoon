import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Settings } from 'lucide-react';
import { HealthRange } from '../types';
import { defaultRanges } from '../data/mockData';
import { Badge } from './ui/badge';

export function RangeConfiguration() {
  const [ranges, setRanges] = useState<HealthRange[]>(defaultRanges);
  const [editMode, setEditMode] = useState(false);

  const updateRange = (type: string, field: keyof HealthRange, value: number) => {
    setRanges(ranges.map(r =>
      r.type === type ? { ...r, [field]: value } : r
    ));
  };

  const getRangeLabel = (type: string) => {
    switch (type) {
      case 'glucose': return 'Glucosa (mg/dL)';
      case 'systolic': return 'Presión Sistólica (mmHg)';
      case 'diastolic': return 'Presión Diastólica (mmHg)';
      default: return type;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            <CardTitle>Configuración de Rangos</CardTitle>
          </div>
          <Button
            onClick={() => setEditMode(!editMode)}
            variant={editMode ? 'default' : 'outline'}
            size="sm"
          >
            {editMode ? 'Guardar' : 'Editar'}
          </Button>
        </div>
        <CardDescription>
          Valores configurados por el médico para detectar lecturas fuera de rango
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {ranges.map((range) => (
          <div key={range.type} className="space-y-4">
            <div>
              <h3 className="font-medium mb-3">{getRangeLabel(range.type)}</h3>
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor={`${range.type}-low`}>Límite Bajo</Label>
                      <Badge variant="destructive" className="text-xs">Riesgo</Badge>
                    </div>
                    <Input
                      id={`${range.type}-low`}
                      type="number"
                      value={range.low}
                      disabled={!editMode}
                      onChange={(e) => updateRange(range.type, 'low', parseFloat(e.target.value))}
                      className={editMode ? 'border-primary' : ''}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor={`${range.type}-normalMin`}>Normal Mínimo</Label>
                      <Badge variant="default" className="text-xs">Normal</Badge>
                    </div>
                    <Input
                      id={`${range.type}-normalMin`}
                      type="number"
                      value={range.normalMin}
                      disabled={!editMode}
                      onChange={(e) => updateRange(range.type, 'normalMin', parseFloat(e.target.value))}
                      className={editMode ? 'border-primary' : ''}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor={`${range.type}-normalMax`}>Normal Máximo</Label>
                      <Badge variant="default" className="text-xs">Normal</Badge>
                    </div>
                    <Input
                      id={`${range.type}-normalMax`}
                      type="number"
                      value={range.normalMax}
                      disabled={!editMode}
                      onChange={(e) => updateRange(range.type, 'normalMax', parseFloat(e.target.value))}
                      className={editMode ? 'border-primary' : ''}
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <Label htmlFor={`${range.type}-high`}>Límite Alto</Label>
                      <Badge variant="destructive" className="text-xs">Riesgo</Badge>
                    </div>
                    <Input
                      id={`${range.type}-high`}
                      type="number"
                      value={range.high}
                      disabled={!editMode}
                      onChange={(e) => updateRange(range.type, 'high', parseFloat(e.target.value))}
                      className={editMode ? 'border-primary' : ''}
                    />
                  </div>
                </div>
              </div>
            </div>
            {range !== ranges[ranges.length - 1] && <div className="border-t" />}
          </div>
        ))}

        <div className="bg-muted/50 p-4 rounded-lg space-y-2">
          <h4 className="font-medium text-sm">Interpretación de Rangos</h4>
          <div className="space-y-1 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Badge variant="destructive" className="text-xs">Riesgo</Badge>
              <span>Valores por debajo del límite bajo o por encima del límite alto</span>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="default" className="text-xs">Normal</Badge>
              <span>Valores entre el mínimo normal y el máximo normal</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
