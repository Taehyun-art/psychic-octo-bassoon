export interface MedicationDose {
  id: string;
  medicationName: string;
  dose: string;
  timestamp: Date;
  taken: boolean;
}

export interface GlucoseReading {
  id: string;
  value: number;
  timestamp: Date;
  note?: string;
}

export interface BloodPressureReading {
  id: string;
  systolic: number;
  diastolic: number;
  timestamp: Date;
  note?: string;
}

export interface HealthRange {
  type: 'glucose' | 'systolic' | 'diastolic';
  low: number;
  normalMin: number;
  normalMax: number;
  high: number;
}

export interface Alert {
  id: string;
  type: 'glucose' | 'blood-pressure';
  severity: 'low' | 'high';
  value: number | string;
  timestamp: Date;
  patientId?: string;
  patientName?: string;
}
