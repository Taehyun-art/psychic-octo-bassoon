import { MedicationDose, GlucoseReading, BloodPressureReading, HealthRange, Alert } from '../types';

export const defaultRanges: HealthRange[] = [
  {
    type: 'glucose',
    low: 70,
    normalMin: 70,
    normalMax: 140,
    high: 140,
  },
  {
    type: 'systolic',
    low: 90,
    normalMin: 90,
    normalMax: 120,
    high: 120,
  },
  {
    type: 'diastolic',
    low: 60,
    normalMin: 60,
    normalMax: 80,
    high: 80,
  },
];

export const mockMedications: MedicationDose[] = [
  {
    id: '1',
    medicationName: 'Metformina',
    dose: '500mg',
    timestamp: new Date(2026, 4, 28, 8, 0),
    taken: true,
  },
  {
    id: '2',
    medicationName: 'Enalapril',
    dose: '10mg',
    timestamp: new Date(2026, 4, 28, 8, 0),
    taken: true,
  },
  {
    id: '3',
    medicationName: 'Metformina',
    dose: '500mg',
    timestamp: new Date(2026, 4, 28, 20, 0),
    taken: false,
  },
];

export const mockGlucoseReadings: GlucoseReading[] = [
  { id: '1', value: 95, timestamp: new Date(2026, 4, 25, 7, 30), note: 'En ayunas' },
  { id: '2', value: 165, timestamp: new Date(2026, 4, 25, 13, 0), note: 'Después de almuerzo' },
  { id: '3', value: 88, timestamp: new Date(2026, 4, 26, 7, 0), note: 'En ayunas' },
  { id: '4', value: 155, timestamp: new Date(2026, 4, 26, 19, 0) },
  { id: '5', value: 92, timestamp: new Date(2026, 4, 27, 7, 15), note: 'En ayunas' },
  { id: '6', value: 148, timestamp: new Date(2026, 4, 27, 13, 30) },
  { id: '7', value: 90, timestamp: new Date(2026, 4, 28, 7, 0), note: 'En ayunas' },
];

export const mockBloodPressureReadings: BloodPressureReading[] = [
  { id: '1', systolic: 118, diastolic: 76, timestamp: new Date(2026, 4, 25, 8, 0) },
  { id: '2', systolic: 132, diastolic: 84, timestamp: new Date(2026, 4, 25, 20, 0), note: 'Después de trabajo' },
  { id: '3', systolic: 115, diastolic: 72, timestamp: new Date(2026, 4, 26, 8, 0) },
  { id: '4', systolic: 128, diastolic: 82, timestamp: new Date(2026, 4, 26, 20, 0) },
  { id: '5', systolic: 112, diastolic: 70, timestamp: new Date(2026, 4, 27, 8, 0) },
  { id: '6', systolic: 138, diastolic: 88, timestamp: new Date(2026, 4, 27, 20, 0), note: 'Estrés laboral' },
  { id: '7', systolic: 116, diastolic: 74, timestamp: new Date(2026, 4, 28, 8, 0) },
];

export const mockAlerts: Alert[] = [
  {
    id: '1',
    type: 'glucose',
    severity: 'high',
    value: 165,
    timestamp: new Date(2026, 4, 25, 13, 0),
    patientId: 'P001',
    patientName: 'Juan Pérez',
  },
  {
    id: '2',
    type: 'blood-pressure',
    severity: 'high',
    value: '132/84',
    timestamp: new Date(2026, 4, 25, 20, 0),
    patientId: 'P001',
    patientName: 'Juan Pérez',
  },
  {
    id: '3',
    type: 'blood-pressure',
    severity: 'high',
    value: '138/88',
    timestamp: new Date(2026, 4, 27, 20, 0),
    patientId: 'P001',
    patientName: 'Juan Pérez',
  },
  {
    id: '4',
    type: 'glucose',
    severity: 'high',
    value: 155,
    timestamp: new Date(2026, 4, 26, 19, 0),
    patientId: 'P002',
    patientName: 'María García',
  },
];
