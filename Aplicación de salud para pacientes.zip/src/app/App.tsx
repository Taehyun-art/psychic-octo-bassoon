import { BrowserRouter, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Dashboard } from './components/Dashboard';
import { MedicationTracker } from './components/MedicationTracker';
import { GlucoseTracker } from './components/GlucoseTracker';
import { BloodPressureTracker } from './components/BloodPressureTracker';
import { AlertsPanel } from './components/AlertsPanel';
import { RangeConfiguration } from './components/RangeConfiguration';
import { Button } from './components/ui/button';
import { LayoutDashboard, Pill, Droplet, Heart, AlertTriangle, Settings } from 'lucide-react';

function Navigation() {
  const location = useLocation();

  const navItems = [
    { path: '/', icon: LayoutDashboard, label: 'Panel' },
    { path: '/medications', icon: Pill, label: 'Medicamentos' },
    { path: '/glucose', icon: Droplet, label: 'Glucosa' },
    { path: '/blood-pressure', icon: Heart, label: 'Presión' },
    { path: '/alerts', icon: AlertTriangle, label: 'Alertas' },
    { path: '/settings', icon: Settings, label: 'Configuración' },
  ];

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <Heart className="h-6 w-6 text-primary" />
            <h1 className="font-bold text-xl">SaludApp</h1>
          </div>
          <div className="flex items-center gap-2">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link key={item.path} to={item.path}>
                  <Button
                    variant={isActive ? 'default' : 'ghost'}
                    size="sm"
                    className="gap-2"
                  >
                    <Icon className="h-4 w-4" />
                    <span className="hidden sm:inline">{item.label}</span>
                  </Button>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="min-h-screen bg-background">
        <Navigation />
        <main className="container mx-auto px-4 py-8">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/medications" element={<MedicationTracker />} />
            <Route path="/glucose" element={<GlucoseTracker />} />
            <Route path="/blood-pressure" element={<BloodPressureTracker />} />
            <Route path="/alerts" element={<AlertsPanel />} />
            <Route path="/settings" element={<RangeConfiguration />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}