
  # Aplicación de salud para pacientes

  This is a code bundle for Aplicación de salud para pacientes. The original project is available at https://www.figma.com/design/2L3cqfuOiNDbG52vNZqOMU/Aplicaci%C3%B3n-de-salud-para-pacientes.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  